COE528 BookStoreApp

How to run:
1. Open the folder BookStoreApp in NetBeans 16 as a Java project.
2. Run the project.
3. Owner login: admin / admin
4. Sample customer login: jane / 1234

Notes:
- Java Swing only
- Single-window GUI using one JFrame and CardLayout
- No Maven
- No Gradle
- Data is loaded from books.txt and customers.txt when the program starts
- Data is saved back to books.txt and customers.txt when the window closes
